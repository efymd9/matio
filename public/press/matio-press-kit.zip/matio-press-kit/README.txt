MATIO — PRESS KIT
=================

Boilerplate (use verbatim):
Matio is an independent studio making dark romantic stories and short
series with more than 12 AI tools. The entire process — from script to
final frame — happens within the team. Every episode is free to watch.

Contents:
  matio-wordmark.png        Wordmark (PNG, transparent)
  matio-logomark.png        Logomark (PNG, transparent, 1620x1620)
  stills/                   4 production stills (JPEG, incl. one 4K)

Usage:
  Gold mark on espresso or brand red only.
  Don't recolour, outline or rotate it.

Contact: contact@matio.tv — interviews, screeners, stills beyond the kit.
Site: https://matio.tv

Matio is a project by DEEP ORDINARY LTD, registered in England and Wales
(company no. 17381666).
